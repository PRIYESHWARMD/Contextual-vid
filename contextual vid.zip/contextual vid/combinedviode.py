#! C:\Users\Priyeshwar\Downloads\basecode\tts\Scripts\python.exe
import requests
from pytube import YouTube

def download_video(url, filename):
    try:
        print("Downloading video...")
        response = requests.get(url)
        with open(filename, 'wb') as f:
            f.write(response.content)
        print("Download complete")
    except Exception as e:
        print(f"Failed to download video: {e}")

def download_youtube_video(url, filename):
    try:
        print("Downloading YouTube video...")
        yt = YouTube(url)
        video = yt.streams.filter(progressive=True, file_extension='mp4').first()
        video.download(filename=filename)
        print("Download complete")
    except Exception as e:
        print(f"Failed to download YouTube video: {e}")

def download_from_url(url, filename):
    if "youtube.com" in url:
        download_youtube_video(url, filename)
    else:
        download_video(url, filename)

# Example usage
url = "https://www.youtube.com/watch?v=WLQ6HyFbfKU"

 # Choose your desired filename here
filename = "u1tube.mp4"  # Choose your desired filename here

download_from_url(url, filename)
