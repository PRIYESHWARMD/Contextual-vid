#! C:\Users\Priyeshwar\Downloads\basecode\tts\Scripts\python.exe
from googletrans import Translator
import logging
from faster_whisper import WhisperModel
from moviepy.editor import VideoFileClip
from googletrans import Translator
from gtts import gTTS
import os
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lex_rank import LexRankSummarizer
# Function to translate text (assuming it's defined elsewhere in your code)
def translate_text(text, target_language):
    translator = Translator()  # Initialize translator without specifying target language
    translated_text = translator.translate(text, dest=target_language).text
    return translated_text

# Function to translate text from file
def translate_text_from_file(input_file, target_language):
    translated_segments = []
    with open(input_file, "r") as file:
        for line in file:
            translated_text = translate_text(line.strip(), target_language)
            translated_segments.append(translated_text)
    return translated_segments

input_file = "transcription_segments.txt"  # Path to the input file containing segments to be translated

target_language = input("Enter the target language code (e.g., 'de' for German): ")  

translated_segments = translate_text_from_file(input_file, target_language)

# Write translated segments to a file
with open("translated_segments.txt", "w") as file:
    for translated_segment in translated_segments:
        file.write(translated_segment + "\n")

print("Translation completed.")



# Function to summarize text from a file
def summarize_text_from_file(input_file):
    # Read the contents of the input file
    with open(input_file, "r") as file:
        text = file.read()

    # Calculate the number of sentences to include in the summary (25% of total sentences)
    num_sentences = int(len(text.split('.')) * 0.25)

    # Initialize parser and tokenizer
    parser = PlaintextParser.from_string(text, Tokenizer("english"))

    # Initialize LexRank summarizer
    summarizer = LexRankSummarizer()

    # Summarize the text
    summary = summarizer(parser.document, num_sentences)

    # Return the summary as a list of sentences
    return [str(sentence) for sentence in summary]

# Summarize text from the input file
summary_sentences = summarize_text_from_file(input_file)

# Print the summary
for sentence in summary_sentences:
    print(sentence)
print("summarizer completed.")
import tensorflow as tf
from transformers import TFGPT2LMHeadModel, GPT2Tokenizer

tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
model = TFGPT2LMHeadModel.from_pretrained("gpt2", pad_token_id=tokenizer.eos_token_id)
def generate_text_from_file(input_file):
    with open(input_file, "r") as file:
        input_text = file.read()

    input_ids = tokenizer.encode(input_text, return_tensors='tf')
    beam_output = model.generate(input_ids, max_length=100, num_beams=5, no_repeat_ngram_size=2, early_stopping=True)
    output = tokenizer.decode(beam_output[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    return ".".join(output.split(".")[:-1]) + "."


output_text = generate_text_from_file(input_file)
print(output_text)
print("generator completed.")


def text_to_speech(translate_input_file, lang, output_file='output.mp3'):
    # Read text from input file
    with open(translate_input_file , 'r', encoding='latin-1') as file:
        text = file.read().replace('\n', ' ')
    
    # Generate speech
    tts = gTTS(text=text, lang=lang, slow=False)
    tts.save(output_file)

# Example usage:
translate_input_file = "translated_segments.txt"

text_to_speech(translate_input_file, target_language)